========================================
  Saarthi Desktop App - Installation
========================================

INSTALLATION:
1. Double-click "Install-Saarthi.bat"
2. Wait 1-2 minutes
3. Launch from Desktop or Start Menu

REQUIREMENTS:
- Windows 10/11
- Internet connection
- Node.js (will use if installed)

SUPPORT: borudeyash1@gmail.com
